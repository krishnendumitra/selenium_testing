package com.PageFactory;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Booking {
	
	WebDriver driver;
	int pass_count;
	Random ran = new Random();
	
	public Booking(WebDriver driver, int pass_count){
		this.driver=driver;
		this.pass_count=pass_count;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//input[@name='creditnumber']")
	WebElement creditnumber;
	
	@FindBy(xpath="//input[@name='cc_frst_name']")
	WebElement cc_frst_name;
	
	@FindBy(xpath="//input[@name='cc_last_name']")
	WebElement cc_last_name;
	
	@FindBy(xpath="//input[@name='buyFlights']")
	WebElement buyFlights;
	
	public void booking() {
		for(int i =0;i<=pass_count;i++) {
			driver.findElement(By.xpath("//input[@name='passFirst"+i+"']")).sendKeys("Passenger"+i);
			driver.findElement(By.xpath("//input[@name='passLast"+i+"']")).sendKeys("Passenger"+i);
			Select passMeal = new Select(driver.findElement(By.xpath("//select[@name='pass."+i+".meal']")));
			passMeal.selectByIndex(ran.nextInt(9));
		}
		this.creditnumber.sendKeys("1234");
		this.cc_frst_name.sendKeys("ABC");
		this.cc_last_name.sendKeys("DEF");
		this.buyFlights.click();
	}

}
