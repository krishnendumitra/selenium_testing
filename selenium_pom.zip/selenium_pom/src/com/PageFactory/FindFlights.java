package com.PageFactory;

import java.util.List;
import java.util.Random;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class FindFlights {

	WebDriver driver;
	Random ran = new Random();

	public FindFlights(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//select[@name='passCount']")
	WebElement passcount;

	@FindBy(xpath="//select[@name='fromPort']")
	WebElement fromPort;

	@FindBy(xpath="//select[@name='fromMonth']")
	WebElement fromMonth;

	@FindBy(xpath="//select[@name='fromDay']")
	WebElement fromDay;

	@FindBy(xpath="//select[@name='toPort']")
	WebElement toPort;

	@FindBy(xpath="//select[@name='toMonth']")
	WebElement toMonth;

	@FindBy(xpath="//select[@name='toDay']")
	WebElement toDay;

	@FindBys(@FindBy(xpath="//input[@name='servClass']"))
	List<WebElement> servClass;

	@FindBy(xpath="//select[@name='airline']")
	WebElement airline;

	@FindBy(xpath="//input[@name='findFlights']")
	WebElement findFlights;

	public int fillingDetails() {
		Select passcount = new Select(this.passcount);
		int pass_count = ran.nextInt(4);
		passcount.selectByIndex(pass_count);
		
		Select fromPort = new Select(this.fromPort);
		fromPort.selectByIndex(ran.nextInt(10));

		Select fromMonth = new Select(this.fromMonth);
		fromMonth.selectByIndex(ran.nextInt(12));

		Select fromDay = new Select(this.fromDay);
		fromDay.selectByIndex(ran.nextInt(30));

		Select toPort = new Select(this.toPort);
		toPort.selectByIndex(ran.nextInt(10));

		Select toMonth = new Select(this.toMonth);
		toMonth.selectByIndex(ran.nextInt(12));

		Select toDay = new Select(this.toDay);
		toDay.selectByIndex(ran.nextInt(30));

		this.servClass.get(ran.nextInt(servClass.size())).click();

		Select airline = new Select(this.airline);
		airline.selectByIndex(ran.nextInt(2));

		findFlights.click();
		return pass_count;
	}

}
