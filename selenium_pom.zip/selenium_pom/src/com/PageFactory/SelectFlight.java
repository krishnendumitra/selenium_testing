package com.PageFactory;

import java.util.List;
import java.util.Random;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

public class SelectFlight {
	
	WebDriver driver;
	Random ran = new Random();
	
	public SelectFlight(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBys(@FindBy(xpath="//input[@name='outFlight']"))
	List<WebElement> outFlight;
	
	@FindBys(@FindBy(xpath="//input[@name='inFlight']"))
	List<WebElement> inFlight;
	
	@FindBy(xpath="//input[@name='reserveFlights']")
	WebElement reserveFlights;
	
	public void selectFlights() {
		
		this.outFlight.get(ran.nextInt(this.outFlight.size())).click();
		
		this.inFlight.get(ran.nextInt(this.inFlight.size())).click();
		
		this.reserveFlights.click();
		
	}

}
