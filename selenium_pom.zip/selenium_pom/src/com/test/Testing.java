package com.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.PageFactory.Booking;
import com.PageFactory.FindFlights;
import com.PageFactory.Home;
import com.PageFactory.LogOut;
import com.PageFactory.SelectFlight;

public class Testing {
	
	WebDriver driver;
	
	@BeforeTest
    public void setup(){
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Spothireddy\\Desktop\\Training\\Testing\\chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.navigate().to("http://newtours.demoaut.com/");
    }
	@Test
	public void test() {
		
		Home home = new Home(driver);
		home.login("readonly","readonly");
		FindFlights findflights = new FindFlights(driver);
		int pass_count = findflights.fillingDetails();
		SelectFlight selectflight = new SelectFlight(driver);
		selectflight.selectFlights();
		Booking booking = new Booking(driver,pass_count);
		booking.booking();
		LogOut logout = new LogOut(driver);
		logout.signoff();
				
	}

}
