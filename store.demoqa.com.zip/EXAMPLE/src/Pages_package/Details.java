package Pages_package;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Details {

	WebDriver driver;
	public Details(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	

		
	@FindBy(xpath="//input[@name='collected_data[9]']")	
	WebElement email;	
		
	@FindBy(xpath="//input[@name='collected_data[2]']")	           
	WebElement firstname;
	
	@FindBy(xpath="//input[@name='collected_data[3]']")	           
	WebElement lastname;
	
	@FindBy(xpath="//textarea[@name='collected_data[4]']")	           
	WebElement address;
	
	@FindBy(xpath="//input[@name='collected_data[5]']")	           
	WebElement city;
	
	@FindBy(xpath="//input[@name='collected_data[6]']")	           
	WebElement state;
	
	@FindBy(xpath="//input[@name='collected_data[8]']")	           
	WebElement postal;
	
	@FindBy(xpath="//input[@name='collected_data[18]']")	           
	WebElement phone;
	
	@FindBy(xpath="//input[@value='Purchase']")
	WebElement purchase;
	
	@FindBy(xpath="//input[@name='shippingSameBilling']")
	WebElement same;
	
	
	
	
	
	
	public void register(String email1,String firstname1,String lastname1,String address1,String city1,String state1,String country1,String postal1,String phone1) throws InterruptedException
	{
		
		email.sendKeys(email1);
		firstname.sendKeys(firstname1);
		lastname.sendKeys(lastname1);
		address.sendKeys(address1);
		city.sendKeys(city1);
	    state.sendKeys(state1);
	    Select country = new Select(driver.findElement(By.xpath("//select[@name=\"collected_data[7][0]\"]")));
	    country.selectByVisibleText(country1);
	    postal.sendKeys(postal1);
	    phone.sendKeys(phone1);
	    Thread.sleep(10000);
	    same.click();
	    purchase.click();
	}
	
}

	
	

