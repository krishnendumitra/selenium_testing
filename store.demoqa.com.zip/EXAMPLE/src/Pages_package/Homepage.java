package Pages_package;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Homepage {

	WebDriver driver;
	public Homepage(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
}
	
@FindBy(xpath="//a[text()='Product Category']")
WebElement product_catgry ;
@FindBy(xpath="//a[text()='Accessories']")
WebElement acc;



public void Select()  {
	
	
	Actions action = new Actions(this.driver);	
	action.moveToElement(this.product_catgry).build().perform();
		this.acc.click();
	
}

	
}
