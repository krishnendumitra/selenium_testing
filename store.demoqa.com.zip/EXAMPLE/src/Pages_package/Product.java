package Pages_package;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Product {

	WebDriver driver;
	public Product(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
@FindBy(xpath="(//input[@type='submit'])[1]")
WebElement add1;
@FindBy(xpath="(//input[@type='submit'])[2]")
WebElement add2;

@FindBy(xpath="//a[@title='Checkout']")
WebElement checkout;

@FindBy(xpath="//span[text()='Continue']")
WebElement conti;


public void assce() throws InterruptedException {
	

	this.add1.click();
	this.add2.click();
	Thread.sleep(5000);
	this.checkout.click();
	this.conti.click();
	
}

}
