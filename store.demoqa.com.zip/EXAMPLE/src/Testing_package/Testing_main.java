
package Testing_package;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages_package.Details;
import Pages_package.Homepage;
import Pages_package.Product;

public class Testing_main {

	WebDriver driver;

	@BeforeTest
	public  void setUp() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Atrivedi\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("http://store.demoqa.com/");

	}
	@Test
	public void execute() throws InterruptedException 
	{
		
		Homepage home = new Homepage(driver);
		home.Select();
		Product pro = new Product(driver);
		pro.assce();
		Details det=new Details(driver);
		det.register("ashwani@gmail.com", "ashwani", "trivedi", "Flat no.222","hyderabad", "telangana","India", "500081", "4456789990");
		driver.close();

	}
}
